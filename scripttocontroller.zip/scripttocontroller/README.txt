scripttocontroller readme
-------------------
how to use
replace "script.txt" with the script you want to run in the folder and rename it to script.txt
run scripttocontroller.py
and done